<html>
    <head>
        <title>Data storing</title>
        <head>
            <body>
                <center>
                    
<?php
       // servername = localhost;
        //username = root;
        //password = empty;
        //dbname = application;

        $conn =  mysqli_connect("localhost", "root", "", "application");

        if ($conn === false){
            die("Connection Failed! "
            . mysqli_connect_error());
        }
        $first_name =mysqli_real_escape_string($conn, $_POST['firstname']);
        $middle_name =mysqli_real_escape_string($conn, $_POST['middlename']);
        $last_name =mysqli_real_escape_string($conn, $_POST['lastname']);
        $Date_of_birth =mysqli_real_escape_string($conn, $_POST['Dateofbirth']);
        $citizenship =mysqli_real_escape_string($conn, $_POST['citizenship']);
        $country =mysqli_real_escape_string($conn, $_POST['country']);
        $county_of_birth =mysqli_real_escape_string($conn, $_POST['countyofbirth']);
        $id=mysqli_real_escape_string($conn, $_POST['id']);
        $Gender =mysqli_real_escape_string($conn, $_POST['Gender']);
        $years_of_formal_education_in_english =mysqli_real_escape_string($conn, $_POST['yearsofformaleducationinenglish']);
        $level_of_education =mysqli_real_escape_string($conn, $_POST['levelofeducation']);
        $other_languages_spoken_or_written =mysqli_real_escape_string($conn, $_POST['otherlanguagesspokenorwritten']);
        $disability =mysqli_real_escape_string($conn, $_POST['disability']);
        $email =mysqli_real_escape_string($conn, $_POST['email']);
        $course =mysqli_real_escape_string($conn, $_POST['course']);
        
            $sql = "INSERT INTO personalinformation (first_name, middle_name, last_name, Date_of_birth, citizenship, country, county_of_birth, id, Gender, years_of_formal_education_in_english, level_of_education, other_languages_spoken_or_written, disability, email, course)VALUES('$first_name', '$middle_name', '$last_name', '$Date_of_birth', '$citizenship', '$country', '$county_of_birth', '$id', '$Gender', '$years_of_formal_education_in_english', '$level_of_education', '$other_languages_spoken_or_written', '$disability', '$email', '$course')";

            if (mysqli_query($conn, $sql)){
                echo "record inserted succesfully";
              }
                else{
                    echo "Error: Sorry $sql. " 
                    .mysqli_error($conn);
                }
                mysqli_close($conn);

                $headers="From: NoelleMaingi@spu.ac.ke";
                $subject="Successful Submission";
                $message="The email has a standard format :  Dear $last_name $first_name , Your application has been successfully submitted for $course . Please await the outcome in two weeks time . Yours Registrar";

                mail($email,$subject,$message,$headers);

                ?>
                </center>
                <body>
                    <html>
            
        
    